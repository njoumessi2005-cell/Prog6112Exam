/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.question2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Question2Test {

    @Test
    public void GetVat_WithValidData_ReturnsCorrectValue() {
        // Unit Test 1: Verify that the GetVat method correctly calculates the VAT amount[cite: 3]
        double basePrice = 3500.0;
        ProductCalculations calc = new ProductCalculations(basePrice);
        
        double expectedVat = 525.0; // 15% of 3500.0
        assertEquals(expectedVat, calc.GetVat(), 0.001);
    }

    @Test
    public void GetTotal_WithValidData_ReturnsCorrectValue() {
        // Unit Test 2: Verify that the GetTotal method correctly calculates the total sale amount[cite: 3]
        double basePrice = 3500.0;
        ProductCalculations calc = new ProductCalculations(basePrice);
        
        double expectedTotal = 4200.0; // 3500.0 (Price) + 525.0 (VAT) + 175.0 (Commission)
        assertEquals(expectedTotal, calc.GetTotal(), 0.001);
    }
}