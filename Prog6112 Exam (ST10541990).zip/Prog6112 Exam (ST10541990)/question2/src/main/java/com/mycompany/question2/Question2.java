/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question2;

/**
 *
 * @author Student
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

// Interface required by Q.2.5[cite: 2]
interface IProductCalculations {
    double GetVat();
    double GetCommission();
    double GetTotal();
}

// Calculations class required by Q.2.5[cite: 2]
class ProductCalculations implements IProductCalculations {
    private double price;

    public ProductCalculations(double price) {
        this.price = price;
    }

    @Override
    public double GetVat() {
        return price * 0.15; // 15% VAT
    }

    @Override
    public double GetCommission() {
        return price * 0.05; // 5% Commission
    }

    @Override
    public double GetTotal() {
        return price + GetVat() + GetCommission();
    }
}

public class Question2 extends JFrame {
    private JTextField txtCustomerName;
    private JTextField txtProductPrice;
    private JComboBox<String> cmbProducts;
    private JButton btnProcess;

    public Question2() {
        setTitle("Mattress Order Application");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Initialize components
        txtCustomerName = new JTextField(15);
        txtProductPrice = new JTextField(15);
        
        String[] products = { "Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket" };
        cmbProducts = new JComboBox<>(products);
        
        btnProcess = new JButton("Process");

        // Layout setup (Q.2.2)[cite: 1]
        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        panel.add(new JLabel("Customer Name:"));
        panel.add(txtCustomerName);
        
        panel.add(new JLabel("Product Name:"));
        panel.add(cmbProducts);
        
        panel.add(new JLabel("Product Price (R):"));
        panel.add(txtProductPrice);
        
        panel.add(new JLabel(""));
        panel.add(btnProcess);

        add(panel, BorderLayout.CENTER);

        // Menu System Setup (Q.2.4)[cite: 2]
        JMenuBar menuBar = new JMenuBar();
        
        JMenu menuFile = new JMenu("File");
        JMenuItem itemExit = new JMenuItem("Exit");
        menuFile.add(itemExit);
        
        JMenu menuTools = new JMenu("Tools");
        JMenuItem itemProcess = new JMenuItem("Process");
        JMenuItem itemClear = new JMenuItem("Clear");
        menuTools.add(itemProcess);
        menuTools.add(itemClear);
        
        menuBar.add(menuFile);
        menuBar.add(menuTools);
        setJMenuBar(menuBar);

        // Action Listeners
        ActionListener processAction = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                processOrder();
            }
        };

        btnProcess.addActionListener(processAction);
        itemProcess.addActionListener(processAction);

        // Clear menu action (Q.2.4)[cite: 2]
        itemClear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtCustomerName.setText("");
                txtProductPrice.setText("");
                cmbProducts.setSelectedIndex(0);
            }
        });

        // Exit menu action (Q.2.4)[cite: 2]
        itemExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }

    private void processOrder() {
        try {
            String customerName = txtCustomerName.getText().trim();
            String productName = (String) cmbProducts.getSelectedItem();
            double price = Double.parseDouble(txtProductPrice.getText().trim());

            if (customerName.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter customer name.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            ProductCalculations calc = new ProductCalculations(price);
            double vat = calc.GetVat();
            double commission = calc.GetCommission();
            double total = calc.GetTotal();

            // Display message dialog matching Q.2.1[cite: 1]
            String message = String.format("Customer Name: %s\nProduct: %s\nVAT: R %.1f\nCOMMISSION: R %.1f\nTOTAL: R %.1f",
                    customerName, productName, vat, commission, total);
            
            JOptionPane.showMessageDialog(this, message, "Message", JOptionPane.INFORMATION_MESSAGE);

            // Save to data.txt matching Q.2.3 format[cite: 1]
            try (PrintWriter writer = new PrintWriter(new FileWriter("data.txt", true))) {
                writer.println("DATA LOG");
                writer.println("*********************************************");
                writer.println("Customer Name: " + customerName);
                writer.println("Product: " + productName);
                writer.println("VAT: R " + vat);
                writer.println("COMMISSION: R " + commission);
                writer.println("TOTAL: R " + total);
                writer.println("*********************************************");
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid numeric price.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error writing to file: " + ex.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Question2().setVisible(true);
            }
        });
    }
}