/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question1;


/**
 *
 * @author Student
 */

import java.util.Scanner;

// Q.1.2: Interface defining the required operations
interface IProduct {
    int GetTotalProductsSold();
    double GetAverageProductSold();
    String GetMostPopularProduct();
}

// Product class implementing single and two-dimensional arrays for sales data
class Product implements IProduct {
    private String[] productNames;
    private int[][] salesData;

    public Product(String[] productNames, int[][] salesData) {
        this.productNames = productNames;
        this.salesData = salesData;
    }

    @Override
    public int GetTotalProductsSold() {
        int total = 0;
        for (int i = 0; i < salesData.length; i++) {
            for (int j = 0; j < salesData[i].length; j++) {
                total += salesData[i][j];
            }
        }
        return total;
    }

    @Override
    public double GetAverageProductSold() {
        int totalSales = GetTotalProductsSold();
        int totalDataPoints = 0;
        for (int[] row : salesData) {
            totalDataPoints += row.length;
        }
        if (totalDataPoints == 0) return 0.0;
        return (double) totalSales / totalDataPoints;
    }

    @Override
    public String GetMostPopularProduct() {
        int maxSale = -1;
        String bestProductAndMonth = "";

        for (int i = 0; i < salesData.length; i++) {
            for (int j = 0; j < salesData[i].length; j++) {
                if (salesData[i][j] > maxSale) {
                    maxSale = salesData[i][j];
                    bestProductAndMonth = productNames[i];
                }
            }
        }
        return bestProductAndMonth + " (" + maxSale + ")";
    }
}

// Q.1.3: PrintProduct class responsible for printing the report data
class PrintProduct {
    private IProduct product;

    public PrintProduct(IProduct product) {
        this.product = product;
    }

    public void printReport() {
        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println("**************************************************");
        System.out.println("TOTAL PRODUCT SALES: " + product.GetTotalProductsSold());
        System.out.println("AVERAGE PRODUCT SALES: " + (int) product.GetAverageProductSold());
        System.out.println("MOST POPULAR PRODUCT: " + product.GetMostPopularProduct());
    }
}

// Q.1.1 & Main Runner matching the file name
public class Question1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Single-dimensional array for product names
        String[] productNames = {
            "Cozy Nights Monarch mattress",
            "Restonic Barbados mattress",
            "Sealy Phuket mattress"
        };

        // Two-dimensional array for sales data across 3 months
        int[][] salesData = new int[3][3];

        // Capture user input matching sample screenshot
        for (int i = 0; i < productNames.length; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print("Enter number of sales for month " + (j + 1) + " for " + productNames[i] + ": ");
                salesData[i][j] = scanner.nextInt();
            }
        }

        System.out.println();
        
        // Instantiate and print report
        Product product = new Product(productNames, salesData);
        PrintProduct printer = new PrintProduct(product);
        printer.printReport();

        scanner.close();
    }
}