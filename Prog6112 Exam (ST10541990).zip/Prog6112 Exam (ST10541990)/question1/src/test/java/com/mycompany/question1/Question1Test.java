package test;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Question1Test {

    // Unit Test 1: Verify GetTotalProductsSold method
    @Test
    public void GetTotalProductsSales_WithValidData_ReturnsCorrectValue() {
        // Arrange
        String[] productNames = {"Cozy Nights Monarch mattress", "Restonic Barbados mattress"};
        int[][] salesData = {
            {25, 18, 20},
            {15, 10, 12}
        };
        Product product = new Product(productNames, salesData);

        // Act
        int totalSales = product.GetTotalProductsSold();

        // Assert (Total expected = 25+18+20+15+10+12 = 100)
        assertEquals(100, totalSales, "Total product sales calculation is incorrect.");
    }

    // Unit Test 2: Verify GetAverageProductSold method
    @Test
    public void GetAveragesSales_WithValidData_ReturnsCorrectValue() {
        // Arrange
        String[] productNames = {"Cozy Nights Monarch mattress", "Restonic Barbados mattress"};
        int[][] salesData = {
            {25, 18, 20},
            {15, 10, 12}
        };
        Product product = new Product(productNames, salesData);

        // Act
        double averageSales = product.GetAverageProductSold();

        // Assert (Total = 100, Data points = 6 => Average = 16.6666...)
        assertEquals(16.6666, averageSales, 0.001, "Average product sales calculation is incorrect.");
    }
}
